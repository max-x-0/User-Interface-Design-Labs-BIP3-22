﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using Microsoft.Win32;
using System.Collections.Generic;
using System.IO;
using System.Linq;



namespace Lab13
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public struct SubtitleEntry
    {
        public double StartTime; 
        public string Text;      
    }

    public partial class MainWindow : Window
    {
        private DispatcherTimer _subtitleTimer;
        private List<SubtitleEntry> _subtitles = new List<SubtitleEntry>();
        private int _currentSubtitleIndex = 0;

        public MainWindow()
        {
            InitializeComponent();

            _subtitleTimer = new DispatcherTimer();
            _subtitleTimer.Interval = TimeSpan.FromMilliseconds(200);
            _subtitleTimer.Tick += SubtitleTimer_Tick;

            VideoPlayer.MediaEnded += (s, e) => _subtitleTimer.Stop();
        }

        private void RestartButton_Click(object sender, RoutedEventArgs e)
        {
            if (VideoPlayer.Source != null)
            {
                VideoPlayer.Position = TimeSpan.Zero;
                VideoPlayer.Pause(); 

                _currentSubtitleIndex = 0;

                _subtitleTimer.Stop();

                HideSubtitle(instant: true);
                SubtitleText.Text = "Готово до відтворення";
            }
        }

        private void HideSubtitle(bool instant = false)
        {
            if (instant)
            {
                SubtitleText.Opacity = 0.0;
                SubtitleText.BeginAnimation(OpacityProperty, null);
                return;
            }

            DoubleAnimation fadeOut = new DoubleAnimation
            {
                To = 0.0,
                Duration = TimeSpan.FromSeconds(0.5)
            };

            SubtitleText.BeginAnimation(OpacityProperty, fadeOut);
        }


        private void SubtitleTimer_Tick(object sender, EventArgs e)
        {
            double currentTime = VideoPlayer.Position.TotalSeconds;

            if (_currentSubtitleIndex < _subtitles.Count)
            {
                SubtitleEntry nextSubtitle = _subtitles[_currentSubtitleIndex];

                if (currentTime >= nextSubtitle.StartTime)
                {
                    ShowSubtitle(nextSubtitle.Text);
                    _currentSubtitleIndex++;

                    DispatcherTimer hideTimer = new DispatcherTimer();
                    hideTimer.Interval = TimeSpan.FromSeconds(3);
                    hideTimer.Tick += (s, ev) =>
                    {
                        HideSubtitle();
                        hideTimer.Stop();
                    };
                    hideTimer.Start();
                }
            }
        }

        private void ShowSubtitle(string text)
        {
            SubtitleText.Text = text;

            DoubleAnimation fadeIn = new DoubleAnimation
            {
                To = 1.0,
                Duration = TimeSpan.FromSeconds(0.5)
            };

            SubtitleText.BeginAnimation(OpacityProperty, fadeIn);
        }

        private void LoadVideoButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Відеофайли|*.mp4;*.avi;*.wmv;*.mov|Усі файли|*.*";

            if (openFileDialog.ShowDialog() == true)
            {
                VideoPlayer.Source = new Uri(openFileDialog.FileName);
                VideoPlayer.Stop();
                RestartButton_Click(null, null);
            }
        }

        private void LoadSubtitlesButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Текстові файли субтитрів (*.txt)|*.txt";

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    _subtitles.Clear();
                    _currentSubtitleIndex = 0;

                    string[] lines = File.ReadAllLines(openFileDialog.FileName);

                    foreach (string line in lines)
                    {
                        string[] parts = line.Split('|');
                        if (parts.Length == 2 && double.TryParse(parts[0].Trim(), out double startTime))
                        {
                            _subtitles.Add(new SubtitleEntry { StartTime = startTime, Text = parts[1].Trim() });
                        }
                    }

                    _subtitles = _subtitles.OrderBy(s => s.StartTime).ToList();
                    MessageBox.Show($"Завантажено {_subtitles.Count} субтитрів.", "Успіх", MessageBoxButton.OK, MessageBoxImage.Information);

                    HideSubtitle(instant: true);
                    SubtitleText.Text = "Субтитри завантажено";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Помилка завантаження субтитрів: {ex.Message}", "Помилка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void PlayButton_Click(object sender, RoutedEventArgs e)
        {
            if (VideoPlayer.Source != null)
            {
                VideoPlayer.Play();
                _subtitleTimer.Start();
            }
        }

        private void PauseButton_Click(object sender, RoutedEventArgs e)
        {
            VideoPlayer.Pause();
            _subtitleTimer.Stop();
        }
    }
}
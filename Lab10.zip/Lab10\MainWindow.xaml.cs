﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab10
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void StartAnimationButton_Click(object sender, RoutedEventArgs e)
        {           
            Grid rootGrid = (Grid)this.Content;
            Storyboard fadeOutAndMove = (Storyboard)rootGrid.FindResource("FadeOutAndMove");
         
            AnimatedRectangle.Opacity = 1.0;
            if (AnimatedRectangle.RenderTransform is TranslateTransform transform)
            {
                transform.X = 0;
            }

            if (fadeOutAndMove != null)
            {
                fadeOutAndMove.Begin(this);
            }
            else
            {
                MessageBox.Show("Помилка: Ресурс 'FadeOutAndMove' не знайдено!", "Помилка анімації", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab11
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void ColorComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem selectedItem = ColorComboBox.SelectedItem as ComboBoxItem;

            if (selectedItem != null)
            {
                string colorName = selectedItem.Tag.ToString();

                try
                {  
                    Brush newBackgroundBrush = (Brush)new BrushConverter().ConvertFromString(colorName);

                    this.Background = newBackgroundBrush;
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show($"Помилка при встановленні кольору: {ex.Message}", "Помилка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}